=== Aweco ===
Contributors: anilguzey
Requires at least: 4.5
Tested up to: 5.4
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

 Aweco can be used for any type of blog. 
 It works seamlessly on all devices. 
 Aweco is a stylish template for all your blog projects and creative output. 
 Minimalist and easy to use, it has everything you need to start your website.

 == Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Click on the 'Activate' button to use your new theme right away.
3. Navigate to Appearance > Customize in your admin panel and customize to your taste.

== Credits ==

Bootstrap : https://getbootstrap.com/
WordPress : https://wordpress.org/
Fonts : https://fonts.google.com/
Images : AnilGuzey / https://www.instagram.com/anilguzey_/ - Creative Commons